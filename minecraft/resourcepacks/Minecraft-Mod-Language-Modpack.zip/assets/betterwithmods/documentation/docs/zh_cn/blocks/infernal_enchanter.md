![Infernal Enchanter](block:betterwithmods:infernal_enchanter)

炼狱附魔台是附魔台的高级版本，可以让你可以选择任意等级的指定附魔
炼狱附魔台需要很多书架，你需要把书架(或其他的可以支持附魔的方块)放在附魔台中心附近17x17x17范围内[^1]
有了差不多一个小图书馆的书架后你就可以利用[奥术卷轴](../items/arcane_scrolls.md)来选择任意等级的对应附魔并消耗经验
但是一个物品本身的附魔数量越多附魔的成本也就越高，也就说需要的书架越多 

![古典炼狱图书馆](betterwithmods:infernal_enchanter.png)


[^1]: 这里范围仅仅是为建筑时提供参考，实际要达到最大效果并不需要放太多