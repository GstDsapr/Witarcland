<chapter name="item.ironGearItem.name"/>
<lore>
事实证明石头可被用于简单机器，但在引擎和复杂机器中的高应力和高温环境下表现不佳。
然而铁能胜任这些更为苛刻的任务。
</lore>
<no_lore>
再次升级你的齿轮，由于金属的特性，其可以驱动更复杂的机器。
</no_lore>
<recipes_usages stack="buildcraftcore:gear_iron"/>
