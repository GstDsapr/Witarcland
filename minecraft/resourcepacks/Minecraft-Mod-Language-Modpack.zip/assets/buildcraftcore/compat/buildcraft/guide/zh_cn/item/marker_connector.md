<chapter name="item.markerConnector.name"/>
<lore>
在任何大规模工程项目中，对机器工作区域进行精细控制至关重要，所以你需要一种工具。
</lore>
<no_lore>
地标连接器用于调整体积框的大小或连接路径标的方向。
</no_lore>
<chapter name="信息"/>
使用地标连接器 ，需手持该物品，右击你想要调整的任何虚拟光柱。移动鼠标以进行调整，再次右击以停止调整。
你可以手持地标连接器 Shift 右击虚拟光柱以删除虚拟光柱。
<recipes_usages stack="buildcraftcore:marker_connector"/>
